/*
 * %FFILE%
 * Copyright (C) %YEAR% Prashant A <prashant.barca@gmail.com> %DATE%
 *
 * Distributed under terms of the %LICENSE% license.
 */

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<fcntl.h>
#include<arpa/inet.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<sys/stat.h>
#include<netinet/in.h>
int main()
{
     %HERE%
    return 0;
}
