/*
 * %FFILE%
 * Copyright (C) %YEAR% %USER% <%MAIL%>
 *
 * Distributed under terms of the %LICENSE% license.
 */

#ifndef __%GUARD%__
#define __%GUARD%__

%HERE%

#endif /* !__%GUARD%__ */
