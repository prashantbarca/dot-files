/*
 * %FFILE%
 * Copyright (C) %YEAR% %USER% <%MAIL%>
 *
 * Distributed under terms of the %LICENSE% license.
 */

public class %FILE%
{
	public %FILE%() {
        string s;
		%HERE%
	}
}

